package com.ivl.suggestionsproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuggestionsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuggestionsProjectApplication.class, args);
	}

}
