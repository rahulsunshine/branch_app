package com.ivl.suggestionsproject.controllers;

import com.ivl.suggestionsproject.dao.UserRepository;
import com.ivl.suggestionsproject.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
    @Autowired
    private UserRepository userRepo;

    @PostMapping("/save")
    public void save(@RequestBody Employee emp) {
        userRepo.save(emp);
    }
}
