package com.ivl.suggestionsproject.dao;

import com.ivl.suggestionsproject.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<Employee,Integer> {
}
