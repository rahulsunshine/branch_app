package com.ivl.suggestionsproject.entity;


import javax.persistence.*;

@Entity
@Table(name="employee_main")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="emp_id")
    private int empId;

    @Column(name="emp_name")
    private String empName;

    @Column(name="dept_name")
    private String department;

    @Column(name="location")
    private String location;

    public Employee() {
    }

    public Employee(int empId, String empName, String department, String location) {
        this.empId = empId;
        this.empName = empName;
        this.department = department;
        this.location = location;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
